--1.-creacion base de datos llamada blog
CREATE DATABASE blog
    WITH 
    OWNER = postgres
    ENCODING = 'UTF8'
    CONNECTION LIMIT = -1;

COMMENT ON DATABASE blog
    IS 'desafio 10-02-2022';
--2-Creacion de las tablas 
create table usuario(
	id serial not null,
	email varchar(40),
	primary key(id)
);
create table post(
	id serial not null,
	usuario_id integer,
	titulo varchar(40),
	fecha date,
	primary key(id),
	foreign key(usuario_id) references usuario(id)	
);
create table comentario(
	id serial not null,
	usuario_id integer,
	post_id integer,
	texto text,
	fecha date,
	primary key(id),
	foreign key(usuario_id) references usuario(id),
	foreign key(post_id) references post(id)	
);
--3.-poblado de las tablas mediante importacion de archivos csv
COPY usuario FROM 'C:\Desafio\apoyo 10-02-2022\usuario.csv' csv header;
COPY post FROM 'C:\Desafio\apoyo 10-02-2022\post.csv' csv header;
COPY comentario FROM 'C:\Desafio\apoyo 10-02-2022\comentario.csv' csv header;
--4.-Seleccionar el correo, id y título de todos los post publicados por el usuario 5.
select email, post.id, titulo from usuario inner join post
on post.usuario_id=usuario.id
where usuario.id=5
;
--5. Listar el correo, id y el detalle de todos los comentarios que no hayan sido realizados por el usuario con email usuario06@hotmail.com
select email, comentario.id, texto, fecha from usuario inner join comentario
on usuario.id=comentario.usuario_id
where email<>'usuario06@hotmail.com';
--6. Listar los usuarios que no han publicado ningún post.
select  usuario.id, email from usuario left join post
on usuario.id=post.usuario_id
where post.usuario_id is null;
--7. Listar todos los post con sus comentarios (incluyendo aquellos que no poseen comentarios).
select titulo, texto from post left join comentario
on post.id=comentario.post_id;
--8. Listar todos los usuarios que hayan publicado un post en Junio.
select usuario.id, email from usuario full outer join post
on usuario.id=post.usuario_id
where fecha between '01-06-2020' and '30-06-2020';